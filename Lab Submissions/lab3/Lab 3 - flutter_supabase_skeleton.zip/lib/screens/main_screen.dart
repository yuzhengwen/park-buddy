// TODO: Main screen with navigation
