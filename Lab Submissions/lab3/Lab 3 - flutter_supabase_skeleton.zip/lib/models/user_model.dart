// TODO: Define user model
