// TODO: Initialize and manage Supabase client
