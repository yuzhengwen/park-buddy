// TODO: Define constants
